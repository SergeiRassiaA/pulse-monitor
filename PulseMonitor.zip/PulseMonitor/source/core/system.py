"""Фоновый сборщик системных метрик (CPU / RAM / диск).

Работает в отдельном QThread: psutil-вызовы не выполняются в GUI-потоке,
поэтому интерфейс остаётся отзывчивым даже при медленном диске или
перегрузке системы. Опрос — раз в секунду, как в диспетчере задач.
"""

from __future__ import annotations

import os
import time
from pathlib import Path

import psutil
from PyQt6.QtCore import QThread, pyqtSignal

_GIB = 1024 ** 3


class SystemSampler(QThread):
    """Поток, который раз в `interval_ms` отдаёт снимок состояния системы."""

    sampled = pyqtSignal(dict)
    failed = pyqtSignal(str)

    def __init__(self, interval_ms: int = 1000, parent=None) -> None:
        super().__init__(parent)
        self._interval_s = max(0.25, interval_ms / 1000.0)
        # Диск, на котором живёт пользователь (обычно системный).
        self._disk_root = Path.home().anchor or os.sep
        self._cores = psutil.cpu_count(logical=True) or 0

    # ------------------------------------------------------------------ поток
    def run(self) -> None:  # noqa: D401 — метод Qt
        # Первый вызов cpu_percent только запускает внутренние счётчики.
        psutil.cpu_percent(interval=None)
        self._sleep(0.35)  # короткий прогрев, чтобы первый замер был осмысленным

        while not self.isInterruptionRequested():
            try:
                self.sampled.emit(self._sample())
            except Exception as exc:  # psutil может не знать о каком-то счётчике
                self.failed.emit(str(exc))
            self._sleep(self._interval_s)

    def stop(self) -> None:
        """Попросить поток завершиться и подождать его (не дольше 2 с)."""
        self.requestInterruption()
        if not self.wait(2000):
            self.terminate()

    # ------------------------------------------------------------- внутреннее
    def _sample(self) -> dict:
        cpu = float(psutil.cpu_percent(interval=None))
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage(self._disk_root)
        return {
            "cpu": cpu,
            "cores": self._cores,
            "mem_percent": float(memory.percent),
            "mem_used_gb": memory.used / _GIB,
            "mem_total_gb": memory.total / _GIB,
            "disk_percent": float(disk.percent),
            "disk_used_gb": disk.used / _GIB,
            "disk_total_gb": disk.total / _GIB,
            "disk_root": str(self._disk_root),
        }

    def _sleep(self, seconds: float) -> None:
        """Спать короткими порциями, чтобы быстро реагировать на остановку."""
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if self.isInterruptionRequested():
                return
            time.sleep(min(0.1, max(0.0, deadline - time.monotonic())))
