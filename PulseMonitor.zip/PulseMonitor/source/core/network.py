"""Асинхронный монитор публичного IP и статуса подключения.

Модуль не блокирует GUI-поток: QNetworkAccessManager работает через событийный
цикл Qt. Запросы идут последовательно по списку резервных API — если первый
сервис недоступен или вернул мусор, пробуем следующий.

Наружу отдаются сигналы:
    stateChanged(str)  — "checking" | "online" | "offline"
    ipChanged(str)     — валидный публичный IP
    latencyChanged(int) — время успешного запроса, мс
    checked(bool)      — завершение попытки (True = IP получен)
"""

from __future__ import annotations

import ipaddress
import json
from typing import Final

from PyQt6.QtCore import QElapsedTimer, QObject, QTimer, QUrl, pyqtSignal
from PyQt6.QtNetwork import QNetworkAccessManager, QNetworkReply, QNetworkRequest

from core.config import NETWORK_TIMEOUT_MS, NETWORK_TOTAL_TIMEOUT_MS


class NetworkMonitor(QObject):
    """Периодическая проверка публичного IP без блокировки интерфейса."""

    stateChanged = pyqtSignal(str)
    ipChanged = pyqtSignal(str)
    latencyChanged = pyqtSignal(int)
    checked = pyqtSignal(bool)

    #: (URL, формат ответа). Порядок = приоритет.
    ENDPOINTS: Final[tuple[tuple[str, str], ...]] = (
        ("https://api.ipify.org?format=json", "json"),
        ("https://ipwho.is/", "json"),
        ("https://ipinfo.io/ip", "text"),
        ("https://ifconfig.me/ip", "text"),
    )

    def __init__(self, refresh_ms: int, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._nam = QNetworkAccessManager(self)

        self._timer = QTimer(self)
        self._timer.setInterval(refresh_ms)
        self._timer.timeout.connect(self._auto_check)

        self._state = "offline"
        self._busy = False
        self._shutdown = False
        self._reply: QNetworkReply | None = None
        self._endpoint_index = 0
        self._request_elapsed = QElapsedTimer()
        self._check_elapsed = QElapsedTimer()

    # ------------------------------------------------------------------ API
    def start(self) -> None:
        """Запустить автообновление и сразу выполнить первую проверку."""
        self._timer.start()
        self.check()

    def stop(self) -> None:
        """Остановить таймер и прервать текущий запрос (при выходе)."""
        self._shutdown = True
        self._timer.stop()
        if self._reply is not None:
            self._reply.abort()

    def is_busy(self) -> bool:
        return self._busy

    def check(self) -> None:
        """Начать проверку IP. Повторный вызов во время запроса игнорируется."""
        if self._busy or self._shutdown:
            return
        self._busy = True
        self._endpoint_index = 0
        self._check_elapsed.start()
        self._set_state("checking")
        self._request_next()

    # ------------------------------------------------------------- внутреннее
    def _auto_check(self) -> None:
        # Если предыдущая проверка ещё идёт — просто пропускаем такт.
        if not self._busy:
            self.check()

    def _request_next(self) -> None:
        """Отправить запрос к следующему API из списка."""
        if self._shutdown:
            self._busy = False
            return
        if self._endpoint_index >= len(self.ENDPOINTS):
            self._finish_failure()
            return

        # Общий дедлайн: не даём последовательному перебору API тянуться вечно.
        remaining = NETWORK_TOTAL_TIMEOUT_MS - int(self._check_elapsed.elapsed())
        if remaining <= 250:
            self._finish_failure()
            return

        url, kind = self.ENDPOINTS[self._endpoint_index]
        request = QNetworkRequest(QUrl(url))
        request.setHeader(
            QNetworkRequest.KnownHeaders.UserAgentHeader,
            "PulseMonitor/1.0 (desktop widget)",
        )
        request.setRawHeader(b"Accept", b"application/json, text/plain;q=0.9")
        # Не отдавать закэшированный IP и не ждать вечно.
        request.setAttribute(
            QNetworkRequest.Attribute.CacheLoadControlAttribute,
            QNetworkRequest.CacheLoadControl.AlwaysNetwork,
        )
        request.setAttribute(
            QNetworkRequest.Attribute.RedirectPolicyAttribute,
            QNetworkRequest.RedirectPolicy.NoLessSafeRedirectPolicy,
        )
        request.setTransferTimeout(min(NETWORK_TIMEOUT_MS, remaining))

        self._request_elapsed.start()
        reply = self._nam.get(request)
        self._reply = reply
        # Лямбда с параметром по умолчанию удерживает ссылку на reply.
        reply.finished.connect(lambda r=reply, k=kind: self._handle_reply(r, k))

    def _handle_reply(self, reply: QNetworkReply, kind: str) -> None:
        """Разобрать ответ; при ошибке перейти к следующему API."""
        if reply is not self._reply:
            reply.deleteLater()
            return
        self._reply = None
        latency = int(self._request_elapsed.elapsed())

        try:
            if self._shutdown:
                self._busy = False
                return

            if reply.error() != QNetworkReply.NetworkError.NoError:
                self._next_endpoint()
                return

            payload = bytes(reply.readAll()).decode("utf-8", errors="ignore").strip()
            ip = self._parse_ip(payload, kind)
            if not ip:
                self._next_endpoint()
                return

            self._busy = False
            self.ipChanged.emit(ip)
            self.latencyChanged.emit(latency)
            self._set_state("online")
            self.checked.emit(True)
        finally:
            reply.deleteLater()

    def _next_endpoint(self) -> None:
        self._endpoint_index += 1
        self._request_next()

    def _finish_failure(self) -> None:
        self._busy = False
        self._set_state("offline")
        self.checked.emit(False)

    def _set_state(self, state: str) -> None:
        if state == self._state:
            return
        self._state = state
        self.stateChanged.emit(state)

    @staticmethod
    def _parse_ip(payload: str, kind: str) -> str:
        """Достать IP из JSON/текста и проверить его валидность."""
        if not payload:
            return ""
        if kind == "json":
            try:
                data = json.loads(payload)
            except (json.JSONDecodeError, TypeError):
                return ""
            if not isinstance(data, dict):
                return ""
            # Разные сервисы используют разные имена поля.
            candidate = str(data.get("ip") or data.get("query") or "").strip()
        else:
            candidate = payload.split()[0].strip()

        try:
            ipaddress.ip_address(candidate)
        except ValueError:
            return ""
        return candidate
