"""Локальный журнал действий на SQLite.

Зачем отдельный класс:
  * запись буферизуется и сбрасывается пачкой раз в 250 мс — интерфейс
    не ждёт диска при каждом клике;
  * чтение всегда ограничено LIMIT, поэтому таблица не «тянет» всю базу;
  * включён режим WAL, чтобы даже редкие параллельные операции не блокировали
    чтение.

Схема максимально простая и легко расширяется:
    events(id, ts, kind, message, meta)

kind — категория действия: system / network / search / ui.
meta — необязательный JSON с подробностями (IP, задержка, поисковый запрос).
"""

from __future__ import annotations

import json
import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from PyQt6.QtCore import QObject, QTimer, pyqtSignal

_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      TEXT NOT NULL,
    kind    TEXT NOT NULL,
    message TEXT NOT NULL,
    meta    TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events (ts DESC, id DESC);
"""


class LogStore(QObject):
    """Буферизованный писатель/читатель журнала действий."""

    #: Испускается после фактической записи пачки строк.
    eventsAdded = pyqtSignal(int)
    #: Испускается после полной очистки журнала.
    cleared = pyqtSignal()

    def __init__(self, db_path: Path, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)

        # Одно соединение — весь доступ идёт из GUI-потока.
        self._conn = sqlite3.connect(str(self._path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

        self._closed = False
        self._write_error_reported = False
        self._buffer: list[tuple[str, str, str, str | None]] = []
        self._flush_timer = QTimer(self)
        self._flush_timer.setSingleShot(True)
        self._flush_timer.setInterval(250)
        self._flush_timer.timeout.connect(self.flush)

    # ------------------------------------------------------------------ запись
    def log(self, kind: str, message: str, meta: dict[str, Any] | None = None) -> None:
        """Добавить событие в буфер (на диск уйдёт в течение 250 мс)."""
        if self._closed:
            return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        meta_json = (
            json.dumps(meta, ensure_ascii=False, separators=(",", ":"))
            if meta
            else None
        )
        self._buffer.append((ts, kind, message, meta_json))
        if not self._flush_timer.isActive():
            self._flush_timer.start()

    def flush(self) -> None:
        """Записать все накопленные строки одной транзакцией."""
        self._flush_timer.stop()
        if self._closed or not self._buffer:
            return
        rows, self._buffer = self._buffer, []
        try:
            with self._conn:  # commit / rollback автоматически
                self._conn.executemany(
                    "INSERT INTO events (ts, kind, message, meta) VALUES (?, ?, ?, ?)",
                    rows,
                )
        except sqlite3.Error as exc:
            # Не роняем интерфейс из-за переполненного диска или блокировки.
            if not self._write_error_reported:
                self._write_error_reported = True
                if sys.stderr is not None:
                    print(
                        f"[LogStore] Не удалось записать журнал: {exc}",
                        file=sys.stderr,
                    )
            return
        self._write_error_reported = False
        self.eventsAdded.emit(len(rows))

    # ------------------------------------------------------------------ чтение
    def fetch(self, limit: int = 250, query: str = "") -> list[dict[str, Any]]:
        """Вернуть последние события (новые сверху), опционально с фильтром."""
        if self._closed:
            return []
        self.flush()
        sql = "SELECT id, ts, kind, message, meta FROM events"
        args: list[Any] = []
        if query:
            # Экранируем служебные символы LIKE, чтобы «100%» не превращалось
            # в «любая строка».
            escaped = (
                query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like = f"%{escaped}%"
            sql += " WHERE message LIKE ? ESCAPE '\\' OR kind LIKE ? ESCAPE '\\'"
            args.extend((like, like))
        sql += " ORDER BY id DESC LIMIT ?"
        args.append(int(limit))
        cursor = self._conn.execute(sql, args)
        return [dict(row) for row in cursor.fetchall()]

    # ------------------------------------------------------------------ очистка
    def clear(self) -> None:
        """Удалить все записи журнала."""
        if self._closed:
            return
        self._buffer.clear()
        self._flush_timer.stop()
        with self._conn:
            self._conn.execute("DELETE FROM events")
        self.cleared.emit()

    # ------------------------------------------------------------------ сервис
    @property
    def path(self) -> Path:
        return self._path

    def close(self) -> None:
        """Сбросить буфер и закрыть соединение (вызывается при выходе)."""
        self._flush_timer.stop()
        self.flush()
        self._closed = True
        try:
            self._conn.close()
        except sqlite3.Error:
            pass
