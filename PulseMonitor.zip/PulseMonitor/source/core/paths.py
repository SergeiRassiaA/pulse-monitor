"""Пути к пользовательским данным приложения.

Лог SQLite хранится не рядом с исходниками, а в системной папке данных:
  Windows: %APPDATA%\\PulseMonitor\\history.db
  macOS:   ~/Library/Application Support/PulseMonitor/history.db
  Linux:   ~/.local/share/pulse-monitor/history.db
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def app_data_dir() -> Path:
    """Вернуть папку для данных приложения (создаётся при необходимости)."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming")
        return Path(base) / "PulseMonitor"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "PulseMonitor"
    base = os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share")
    return Path(base) / "pulse-monitor"


def database_path() -> Path:
    """Полный путь к файлу локальной истории действий."""
    return app_data_dir() / "history.db"
