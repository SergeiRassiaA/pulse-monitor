"""Тёмная тема: палитра, шрифты и глобальная таблица стилей (QSS)."""

from __future__ import annotations

from string import Template

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import (
    QColor,
    QFont,
    QFontDatabase,
    QIcon,
    QPainter,
    QPainterPath,
    QPalette,
    QPen,
    QPixmap,
)
from PyQt6.QtWidgets import QApplication

# --------------------------------------------------------------------------
# Палитра
# --------------------------------------------------------------------------
BG = "#0A0E13"          # фон окна
SURFACE = "#10161E"     # фон карточек
SURFACE_ALT = "#151D27" # фон кнопок / всплывающих подсказок
BORDER = "#1E2935"      # границы карточек
BORDER_SOFT = "#17212C" # разделители строк таблицы
TEXT = "#E6EDF3"        # основной текст
MUTED = "#8496A8"       # вторичный текст
MUTED_DIM = "#5D6E80"   # самый тихий текст (подписи, футер)
ACCENT = "#38BDF8"      # голубой акцент (сеть, CPU)
VIOLET = "#A78BFA"      # фиолетовый акцент (RAM)
GREEN = "#34D399"       # зелёный (диск, статус «в сети»)
AMBER = "#FBBF24"       # жёлтый (проверка)
RED = "#F87171"         # красный (ошибка, «не в сети»)
TRACK = "#1A2430"       # фон незаполненной шкалы

_QSS = Template(
    """
QWidget {
    color: ${text};
}
QMainWindow, QWidget#Root {
    background-color: ${bg};
}
QWidget#Card {
    background-color: ${surface};
    border: 1px solid ${border};
    border-radius: 14px;
}
QLabel {
    background: transparent;
}
QLabel#AppTitle {
    font-size: 22px;
    font-weight: 700;
    color: ${text};
}
QLabel#AppSubtitle {
    font-size: 12px;
    color: ${muted};
}
QLabel#CardTitle {
    font-size: 11px;
    font-weight: 700;
    color: ${muted};
}
QLabel#IpValue {
    color: ${text};
}
QLabel#MetricValue {
    font-size: 30px;
    font-weight: 700;
    color: ${text};
}
QLabel#Hint {
    font-size: 11px;
    color: ${muted};
}
QLabel#Footer {
    font-size: 11px;
    color: ${muted_dim};
}
QLabel#EmptyTitle {
    font-size: 14px;
    font-weight: 600;
    color: ${muted};
}
QLabel#EmptyHint {
    font-size: 12px;
    color: ${muted_dim};
}

/* --- Кнопки ----------------------------------------------------------- */
QPushButton {
    background-color: ${surface_alt};
    border: 1px solid ${border};
    border-radius: 10px;
    padding: 8px 14px;
    color: ${text};
    font-weight: 600;
}
QPushButton:hover {
    background-color: #1B2733;
    border-color: #2B3C4D;
}
QPushButton:pressed {
    background-color: #121B25;
}
QPushButton:disabled {
    color: ${muted_dim};
    background-color: #0E151C;
    border-color: ${border_soft};
}
QPushButton#Primary {
    background-color: ${accent};
    color: #04121B;
    border: none;
}
QPushButton#Primary:hover {
    background-color: #5CCBFA;
}
QPushButton#Primary:pressed {
    background-color: #2AA9E0;
}
QPushButton#Primary:disabled {
    background-color: #1B3949;
    color: #6E8798;
}
QPushButton#Ghost {
    background-color: transparent;
    border: 1px solid ${border};
    color: ${muted};
}
QPushButton#Ghost:hover {
    background-color: ${surface_alt};
    color: ${text};
    border-color: #2B3C4D;
}
QPushButton#Ghost:disabled {
    color: ${muted_dim};
    border-color: ${border_soft};
}
QPushButton#Danger {
    background-color: transparent;
    border: 1px solid transparent;
    color: ${muted};
    padding: 6px 10px;
}
QPushButton#Danger:hover {
    color: ${red};
    background-color: rgba(248, 113, 113, 0.08);
    border-color: rgba(248, 113, 113, 0.28);
}
QPushButton#FooterLink {
    background-color: transparent;
    border: none;
    color: ${muted_dim};
    padding: 2px 4px;
    font-size: 11px;
    font-weight: 400;
}
QPushButton#FooterLink:hover {
    color: ${accent};
    background-color: transparent;
}

/* --- Поле поиска ------------------------------------------------------ */
QLineEdit {
    background-color: #0C1219;
    border: 1px solid ${border};
    border-radius: 10px;
    padding: 9px 12px;
    color: ${text};
    selection-background-color: ${accent};
    selection-color: #04121B;
}
QLineEdit:focus {
    border-color: ${accent};
    background-color: #0E1620;
}

/* --- Таблица истории -------------------------------------------------- */
QTableView {
    background-color: transparent;
    border: none;
    gridline-color: transparent;
    selection-background-color: #16232F;
    selection-color: ${text};
    outline: none;
}
QTableView::item {
    border-bottom: 1px solid ${border_soft};
    padding: 2px 6px;
}
QTableView::item:selected {
    background-color: #16232F;
}
QHeaderView::section {
    background-color: transparent;
    color: ${muted};
    border: none;
    border-bottom: 1px solid ${border};
    padding: 8px 6px;
    font-size: 11px;
    font-weight: 700;
}
QTableCornerButton::section {
    background: transparent;
    border: none;
}

/* --- Прокрутка -------------------------------------------------------- */
QScrollArea {
    background: transparent;
    border: none;
}
QScrollArea > QWidget > QWidget {
    background: transparent;
}
QScrollBar:vertical {
    background: transparent;
    width: 10px;
    margin: 2px 2px 2px 0;
}
QScrollBar::handle:vertical {
    background: #253341;
    border-radius: 4px;
    min-height: 32px;
}
QScrollBar::handle:vertical:hover {
    background: #33475B;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: transparent;
}
QScrollBar:horizontal {
    background: transparent;
    height: 10px;
    margin: 0 2px 2px 2px;
}
QScrollBar::handle:horizontal {
    background: #253341;
    border-radius: 4px;
    min-width: 32px;
}
QScrollBar::handle:horizontal:hover {
    background: #33475B;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
    background: transparent;
}
QSplitter::handle {
    background: transparent;
}

/* --- Служебные окна --------------------------------------------------- */
QToolTip {
    background-color: ${surface_alt};
    color: ${text};
    border: 1px solid ${border};
    border-radius: 6px;
    padding: 6px 8px;
}
QMessageBox {
    background-color: ${surface};
}
QMessageBox QLabel {
    color: ${text};
}
"""
)

STYLESHEET = _QSS.substitute(
    bg=BG,
    surface=SURFACE,
    surface_alt=SURFACE_ALT,
    border=BORDER,
    border_soft=BORDER_SOFT,
    text=TEXT,
    muted=MUTED,
    muted_dim=MUTED_DIM,
    accent=ACCENT,
    red=RED,
)


def ui_font() -> QFont:
    """Подобрать доступный системный шрифт без внешних зависимостей."""
    families = set(QFontDatabase.families())
    font = QFont()
    for name in ("Segoe UI Variable Text", "Segoe UI", "Inter", "Noto Sans", "DejaVu Sans"):
        if name in families:
            font.setFamily(name)
            break
    font.setPointSize(10)
    return font


def mono_font(point_size: int = 9, bold: bool = False) -> QFont:
    """Моноширинный шрифт для IP-адреса и колонки времени."""
    families = set(QFontDatabase.families())
    font = QFont()
    for name in ("Cascadia Mono", "JetBrains Mono", "Consolas", "DejaVu Sans Mono", "Courier New"):
        if name in families:
            font.setFamily(name)
            break
    font.setPointSize(point_size)
    font.setBold(bold)
    return font


def apply_theme(app: QApplication) -> None:
    """Применить Fusion-стиль, тёмную палитру, шрифт и QSS."""
    app.setStyle("Fusion")
    app.setFont(ui_font())

    palette = QPalette()
    role = QPalette.ColorRole
    palette.setColor(role.Window, QColor(BG))
    palette.setColor(role.WindowText, QColor(TEXT))
    palette.setColor(role.Base, QColor(SURFACE))
    palette.setColor(role.AlternateBase, QColor(SURFACE_ALT))
    palette.setColor(role.Text, QColor(TEXT))
    palette.setColor(role.Button, QColor(SURFACE_ALT))
    palette.setColor(role.ButtonText, QColor(TEXT))
    palette.setColor(role.BrightText, QColor("#FFFFFF"))
    palette.setColor(role.Highlight, QColor(ACCENT))
    palette.setColor(role.HighlightedText, QColor("#04121B"))
    palette.setColor(role.ToolTipBase, QColor(SURFACE_ALT))
    palette.setColor(role.ToolTipText, QColor(TEXT))
    palette.setColor(role.PlaceholderText, QColor(MUTED_DIM))
    palette.setColor(role.Link, QColor(ACCENT))
    app.setPalette(palette)

    app.setStyleSheet(STYLESHEET)


def app_icon_pixmap(size: int = 64) -> QPixmap:
    """Нарисовать иконку приложения в заданном размере.

    Рисунок выполняется в системе координат 64×64 и масштабируется, поэтому
    иконка остаётся чёткой и в трее (16 px), и в проводнике (256 px).
    """
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.scale(size / 64.0, size / 64.0)

    painter.setPen(QPen(QColor(BORDER), 2))
    painter.setBrush(QColor(SURFACE))
    painter.drawRoundedRect(QRectF(2, 2, 60, 60), 16, 16)

    pen = QPen(QColor(ACCENT), 5)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)

    # Стилизованный «пульс».
    path = QPainterPath(QPointF(13, 35))
    for x, y in ((21, 35), (27, 20), (35, 46), (42, 29), (51, 29)):
        path.lineTo(x, y)
    painter.drawPath(path)
    painter.end()

    return pixmap


def app_icon() -> QIcon:
    """Иконка приложения с наборами размеров для окна, панели задач и трея."""
    icon = QIcon()
    for size in (16, 24, 32, 48, 64, 128, 256):
        icon.addPixmap(app_icon_pixmap(size))
    return icon
