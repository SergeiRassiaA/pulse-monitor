"""Pulse Monitor — точка входа.

Запуск:
    python main.py            # с консолью (отладка)
    pythonw main.py           # без консоли
    pythonw PulseMonitor.pyw  # без консоли, основной способ
    PulseMonitor.pyw          # двойной клик в Windows

Зависимости:
    pip install -r requirements.txt
"""

from __future__ import annotations

import sys
import traceback

from core.config import APP_NAME, VERSION


def _report_startup_error(message: str) -> None:
    """Показать ошибку даже под pythonw, где sys.stderr равен None."""
    if sys.stderr is not None:
        print(message, file=sys.stderr)
    if sys.platform == "win32":
        # У pythonw нет консоли — показываем нативное окно Windows.
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(0, message, APP_NAME, 0x10)
        except Exception:
            pass


def main() -> int:
    # Импорт PyQt6 вынесен внутрь функции, чтобы при отсутствии зависимости
    # вывести понятное сообщение вместо длинного traceback.
    try:
        from PyQt6.QtCore import Qt
        from PyQt6.QtWidgets import QApplication, QMessageBox
    except ImportError as exc:
        _report_startup_error(
            f"Не удалось запустить {APP_NAME}: {exc}\n"
            "Установите зависимости: pip install -r requirements.txt"
        )
        return 1

    # Дробное масштабирование делает интерфейс чётким на экранах 125/150 %.
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    app.setOrganizationName("PulseMonitor")
    app.setApplicationVersion(VERSION)

    try:
        import psutil  # noqa: F401  — проверяем зависимость до импорта UI
    except ImportError:
        QMessageBox.critical(
            None,
            APP_NAME,
            "Не установлена библиотека psutil.\n\n"
            "Выполните в терминале:\n"
            "pip install -r requirements.txt",
        )
        return 1

    try:
        from core.theme import app_icon, apply_theme
        from ui.main_window import MainWindow

        apply_theme(app)
        app.setWindowIcon(app_icon())
        window = MainWindow()
    except Exception as exc:  # noqa: BLE001 — показываем ошибку пользователю
        if sys.stderr is not None:
            traceback.print_exc()
        QMessageBox.critical(
            None,
            APP_NAME,
            f"Не удалось запустить приложение:\n\n{exc}",
        )
        return 1

    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
