"""Переиспользуемые визуальные компоненты.

Содержит:
  * Card          — карточка с фоном и скруглёнными углами;
  * StatusPill    — индикатор состояния сети с пульсацией;
  * Sparkline     — лёгкий график без сторонних библиотек;
  * AnimatedBar   — плавно анимированная шкала загрузки;
  * MetricCard    — карточка метрики (CPU / RAM / диск);
  * fade_in       — короткая анимация появления.
"""

from __future__ import annotations

from collections import deque

from PyQt6.QtCore import (
    QEasingCurve,
    QPointF,
    QPropertyAnimation,
    QRectF,
    QSize,
    Qt,
    QTimer,
    pyqtProperty,
)
from PyQt6.QtGui import (
    QColor,
    QFont,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
)
from PyQt6.QtWidgets import (
    QFrame,
    QGraphicsOpacityEffect,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from core import theme
from core.config import SPARKLINE_POINTS


class Card(QFrame):
    """Базовая карточка: оформление задаётся через QSS по objectName."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)


class StatusPill(QWidget):
    """Компактный статус «В сети / Не в сети / Проверка…» с точкой."""

    _STYLES = {
        "online": (theme.GREEN, "В сети"),
        "offline": (theme.RED, "Не в сети"),
        "checking": (theme.AMBER, "Проверка…"),
    }

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._state = ""
        self._text = ""
        self._pulse = 1.0
        self.setFixedHeight(28)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

        font = QFont(self.font())
        font.setPointSizeF(9.5)
        font.setBold(True)
        self.setFont(font)

        self._pulse_anim = QPropertyAnimation(self, b"pulse", self)
        self._pulse_anim.setDuration(850)
        self._pulse_anim.setStartValue(0.35)
        self._pulse_anim.setEndValue(1.0)
        self._pulse_anim.setEasingCurve(QEasingCurve.Type.InOutSine)
        self._pulse_anim.setLoopCount(-1)

        self.set_state("offline")

    # ----------------------------------------------------------- свойство pulse
    def _get_pulse(self) -> float:
        return self._pulse

    def _set_pulse(self, value: float) -> None:
        self._pulse = float(value)
        self.update()

    pulse = pyqtProperty(float, fget=_get_pulse, fset=_set_pulse)

    # ------------------------------------------------------------------ API
    def set_state(self, state: str) -> None:
        if state not in self._STYLES:
            state = "offline"
        if state == self._state:
            return
        self._state = state
        self._text = self._STYLES[state][1]

        if state == "checking":
            self._pulse_anim.start()
        else:
            self._pulse_anim.stop()
            self._pulse = 1.0
        self.updateGeometry()
        self.update()

    def sizeHint(self) -> QSize:  # noqa: N802 — метод Qt
        width = self.fontMetrics().horizontalAdvance(self._text) + 42
        return QSize(max(112, width), 28)

    # -------------------------------------------------------------- отрисовка
    def paintEvent(self, event) -> None:  # noqa: N802 — метод Qt
        color = QColor(self._STYLES.get(self._state, self._STYLES["offline"])[0])
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)

        background = QColor(color)
        background.setAlpha(26)
        border = QColor(color)
        border.setAlpha(75)
        painter.setBrush(background)
        painter.setPen(QPen(border, 1))
        painter.drawRoundedRect(rect, 14, 14)

        # Точка: пульсирует, пока идёт проверка.
        dot = QColor(color)
        dot.setAlphaF(0.35 + 0.65 * self._pulse)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(dot)
        painter.drawEllipse(QRectF(13, rect.center().y() - 3.5, 7, 7))

        painter.setPen(color)
        text_rect = QRectF(27, 0, self.width() - 32, self.height())
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
            self._text,
        )


class Sparkline(QWidget):
    """Минималистичный график-спарклайн на QPainter (без pyqtgraph)."""

    def __init__(
        self,
        color: str,
        max_points: int = SPARKLINE_POINTS,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._values: deque[float] = deque(maxlen=max_points)
        self._color = QColor(color)
        self.setMinimumHeight(58)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def push(self, value: float) -> None:
        self._values.append(max(0.0, min(100.0, float(value))))
        self.update()

    def clear(self) -> None:
        self._values.clear()
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 — метод Qt
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        width = float(self.width())
        height = float(self.height())

        # Лёгкая сетка: три горизонтальные линии.
        grid_pen = QPen(QColor(theme.BORDER_SOFT), 1)
        painter.setPen(grid_pen)
        for i in range(1, 4):
            y = height * i / 4.0
            painter.drawLine(QPointF(0, y), QPointF(width, y))

        values = list(self._values)
        if len(values) < 2:
            return

        pad_x, pad_y = 4.0, 6.0
        plot_w = max(1.0, width - pad_x * 2)
        plot_h = max(1.0, height - pad_y * 2)
        step = plot_w / (len(values) - 1)

        points = [
            QPointF(pad_x + i * step, pad_y + plot_h * (1.0 - value / 100.0))
            for i, value in enumerate(values)
        ]

        # Сглаженная линия через средние точки.
        path = QPainterPath(points[0])
        for i in range(1, len(points) - 1):
            midpoint = QPointF(
                (points[i].x() + points[i + 1].x()) / 2.0,
                (points[i].y() + points[i + 1].y()) / 2.0,
            )
            path.quadTo(points[i], midpoint)
        path.lineTo(points[-1])

        # Градиентная заливка под линией.
        fill = QPainterPath(path)
        fill.lineTo(points[-1].x(), height)
        fill.lineTo(points[0].x(), height)
        fill.closeSubpath()

        gradient = QLinearGradient(0, 0, 0, height)
        top = QColor(self._color)
        top.setAlpha(64)
        bottom = QColor(self._color)
        bottom.setAlpha(0)
        gradient.setColorAt(0.0, top)
        gradient.setColorAt(1.0, bottom)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(gradient)
        painter.drawPath(fill)

        # Сама линия и точка на последнем значении.
        line_pen = QPen(self._color, 2)
        line_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        line_pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        painter.setPen(line_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)

        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(self._color)
        painter.drawEllipse(points[-1], 3.0, 3.0)


class AnimatedBar(QWidget):
    """Тонкая шкала с плавным изменением значения."""

    def __init__(self, color: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._value = 0.0
        self._color = QColor(color)
        self.setFixedHeight(8)

        self._anim = QPropertyAnimation(self, b"value", self)
        self._anim.setDuration(480)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    # ---------------------------------------------------------- свойство value
    def _get_value(self) -> float:
        return self._value

    def _set_value(self, value: float) -> None:
        self._value = max(0.0, min(100.0, float(value)))
        self.update()

    value = pyqtProperty(float, fget=_get_value, fset=_set_value)

    def animate_to(self, value: float) -> None:
        self._anim.stop()
        self._anim.setStartValue(self._value)
        self._anim.setEndValue(max(0.0, min(100.0, float(value))))
        self._anim.start()

    def paintEvent(self, event) -> None:  # noqa: N802 — метод Qt
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        rect = QRectF(self.rect())
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(theme.TRACK))
        painter.drawRoundedRect(rect, 4, 4)

        if self._value <= 0:
            return

        fill_width = max(7.0, rect.width() * self._value / 100.0)
        fill_rect = QRectF(rect.x(), rect.y(), min(fill_width, rect.width()), rect.height())
        painter.setBrush(self._color)
        painter.drawRoundedRect(fill_rect, 4, 4)


class MetricCard(Card):
    """Карточка одной метрики: заголовок, значение, график/шкала, подпись."""

    def __init__(
        self,
        title: str,
        color: str,
        chart: str = "spark",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setMinimumHeight(176)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(6)

        header = QHBoxLayout()
        header.setSpacing(8)
        title_label = QLabel(title.upper())
        title_label.setObjectName("CardTitle")
        header.addWidget(title_label)
        header.addStretch(1)
        layout.addLayout(header)

        self._value_label = QLabel("—")
        self._value_label.setObjectName("MetricValue")
        layout.addWidget(self._value_label)

        self._chart: Sparkline | None = None
        self._bar: AnimatedBar | None = None
        if chart == "bar":
            layout.addStretch(1)
            self._bar = AnimatedBar(color)
            layout.addWidget(self._bar)
        else:
            self._chart = Sparkline(color)
            layout.addWidget(self._chart, 1)

        self._caption = QLabel("")
        self._caption.setObjectName("Hint")
        layout.addWidget(self._caption)

    def update_metrics(self, percent: float, caption: str) -> None:
        """Обновить цифру, подпись и график."""
        self._value_label.setText(f"{percent:.0f}%")
        self._caption.setText(caption)
        if self._chart is not None:
            self._chart.push(percent)
        if self._bar is not None:
            self._bar.animate_to(percent)


def fade_in(
    widget: QWidget,
    delay_ms: int = 0,
    duration_ms: int = 280,
    keep: list | None = None,
) -> QPropertyAnimation:
    """Мягко проявить виджет; эффект снимается после анимации."""
    effect = QGraphicsOpacityEffect(widget)
    effect.setOpacity(0.0)
    widget.setGraphicsEffect(effect)

    anim = QPropertyAnimation(effect, b"opacity", widget)
    anim.setDuration(duration_ms)
    anim.setStartValue(0.0)
    anim.setEndValue(1.0)
    anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def _cleanup() -> None:
        if widget.graphicsEffect() is effect:
            widget.setGraphicsEffect(None)

    anim.finished.connect(_cleanup)
    QTimer.singleShot(delay_ms, anim.start)
    if keep is not None:
        keep.append(anim)
    return anim
