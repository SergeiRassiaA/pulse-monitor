"""Главное окно: сборка карточек, адаптивная вёрстка и связывание сигналов."""

from __future__ import annotations

from datetime import datetime

from PyQt6.QtCore import QSettings, Qt, QTimer, QUrl
from PyQt6.QtGui import QDesktopServices, QGuiApplication
from PyQt6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from core import theme
from core.config import (
    APP_ID,
    APP_NAME,
    NETWORK_REFRESH_MS,
    SAMPLE_INTERVAL_MS,
    VERSION,
)
from core.database import LogStore
from core.network import NetworkMonitor
from core.paths import database_path
from core.system import SystemSampler
from core.theme import mono_font
from ui.history import HistoryPanel
from ui.widgets import Card, MetricCard, StatusPill, fade_in


class MainWindow(QMainWindow):
    """Окно приложения. Вся тяжёлая работа вынесена в core-модули."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} — сетевой и системный монитор")
        self.setMinimumSize(900, 680)
        self.resize(1280, 840)

        self._settings = QSettings(APP_ID, APP_ID)
        self._store = LogStore(database_path(), self)
        self._net = NetworkMonitor(NETWORK_REFRESH_MS, self)
        self._sampler = SystemSampler(SAMPLE_INTERVAL_MS, self)

        # Состояние интерфейса.
        self._current_ip = ""
        self._had_ip = False
        self._latency_ms: int | None = None
        self._last_check = ""
        self._last_state = ""
        self._sampler_error_logged = False
        self._narrow: bool | None = None
        self._metric_cols = 0
        self._shown = False
        self._animations: list = []

        self._build_ui()
        self._wire_signals()
        self._restore_geometry()
        self._apply_responsive_layout()

        # Первая запись в журнал и запуск фоновых задач.
        self._store.log("system", "Приложение запущено", {"version": VERSION})
        self._net.start()
        self._sampler.start()

    # ================================================================== UI
    def _build_ui(self) -> None:
        root = QWidget()
        root.setObjectName("Root")
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(22, 18, 22, 12)
        root_layout.setSpacing(14)

        root_layout.addWidget(self._build_header())

        self._splitter = QSplitter(Qt.Orientation.Horizontal)
        self._splitter.setChildrenCollapsible(False)
        self._splitter.setHandleWidth(14)
        self._splitter.addWidget(self._build_left_column())
        self._history = HistoryPanel(self._store)
        self._splitter.addWidget(self._history)
        self._splitter.setStretchFactor(0, 3)
        self._splitter.setStretchFactor(1, 2)
        self._splitter.setSizes([760, 460])
        root_layout.addWidget(self._splitter, 1)

        root_layout.addLayout(self._build_footer())
        self.setCentralWidget(root)

    def _build_header(self) -> QWidget:
        header = QWidget()
        layout = QHBoxLayout(header)
        layout.setContentsMargins(2, 0, 2, 0)
        layout.setSpacing(12)

        titles = QVBoxLayout()
        titles.setSpacing(1)
        title = QLabel("Pulse")
        title.setObjectName("AppTitle")
        subtitle = QLabel("Сетевой и системный монитор")
        subtitle.setObjectName("AppSubtitle")
        titles.addWidget(title)
        titles.addWidget(subtitle)

        layout.addLayout(titles)
        layout.addStretch(1)

        hint = QLabel(
            f"Сеть: обновление {NETWORK_REFRESH_MS // 1000} с  ·  "
            f"Система: опрос {SAMPLE_INTERVAL_MS // 1000} с"
        )
        hint.setObjectName("Footer")
        layout.addWidget(hint)
        return header

    def _build_left_column(self) -> QScrollArea:
        left = QWidget()
        layout = QVBoxLayout(left)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(14)

        layout.addWidget(self._build_network_card())

        # Сетка метрик: число колонок меняется в _apply_responsive_layout().
        self._metrics_host = QWidget()
        self._metrics_host.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum
        )
        self._metrics_grid = QGridLayout(self._metrics_host)
        self._metrics_grid.setContentsMargins(0, 0, 0, 0)
        self._metrics_grid.setSpacing(14)

        self._cpu_card = MetricCard("Процессор", theme.ACCENT, "spark")
        self._mem_card = MetricCard("Оперативная память", theme.VIOLET, "spark")
        self._disk_card = MetricCard("Дисковое пространство", theme.GREEN, "bar")
        self._metric_cards = (self._cpu_card, self._mem_card, self._disk_card)
        self._relayout_metrics(3)

        layout.addWidget(self._metrics_host)
        layout.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(left)
        scroll.setMinimumWidth(440)
        self._left_scroll = scroll
        return scroll

    def _build_network_card(self) -> Card:
        card = Card()
        card.setMinimumHeight(144)
        self._network_card = card

        layout = QVBoxLayout(card)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(8)

        top = QHBoxLayout()
        top.setSpacing(10)
        title = QLabel("ПУБЛИЧНЫЙ IP-АДРЕС")
        title.setObjectName("CardTitle")
        self._pill = StatusPill()
        top.addWidget(title)
        top.addStretch(1)
        top.addWidget(self._pill)
        layout.addLayout(top)

        middle = QHBoxLayout()
        middle.setSpacing(10)
        self._ip_label = QLabel("—")
        self._ip_label.setObjectName("IpValue")
        self._ip_label.setFont(mono_font(21, bold=True))
        self._ip_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._ip_label.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred
        )
        middle.addWidget(self._ip_label, 1)

        self._copy_btn = QPushButton("Копировать")
        self._copy_btn.setObjectName("Ghost")
        self._copy_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._copy_btn.setEnabled(False)
        self._refresh_btn = QPushButton("Проверить IP")
        self._refresh_btn.setObjectName("Primary")
        self._refresh_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._refresh_btn.setMinimumWidth(134)
        middle.addWidget(self._copy_btn)
        middle.addWidget(self._refresh_btn)
        layout.addLayout(middle)

        self._net_meta = QLabel("Ожидание первого запроса…")
        self._net_meta.setObjectName("Hint")
        self._net_meta.setWordWrap(True)
        layout.addWidget(self._net_meta)

        # Таймер безопасно сбрасывает текст кнопки «Скопировано».
        self._copy_reset = QTimer(self)
        self._copy_reset.setSingleShot(True)
        self._copy_reset.setInterval(1400)
        self._copy_reset.timeout.connect(lambda: self._copy_btn.setText("Копировать"))
        return card

    def _build_footer(self) -> QHBoxLayout:
        footer = QHBoxLayout()
        footer.setContentsMargins(2, 0, 2, 0)
        footer.setSpacing(6)

        db_label = QLabel("Журнал: history.db")
        db_label.setObjectName("Footer")
        db_label.setToolTip(str(database_path()))

        open_button = QPushButton("Открыть папку")
        open_button.setObjectName("FooterLink")
        open_button.setCursor(Qt.CursorShape.PointingHandCursor)
        open_button.clicked.connect(self._open_log_folder)

        version = QLabel(f"v{VERSION} · PyQt6 · SQLite")
        version.setObjectName("Footer")

        footer.addWidget(db_label)
        footer.addWidget(open_button)
        footer.addStretch(1)
        footer.addWidget(version)
        return footer

    # ============================================================== сигналы
    def _wire_signals(self) -> None:
        self._net.stateChanged.connect(self._on_network_state)
        self._net.ipChanged.connect(self._on_ip)
        self._net.latencyChanged.connect(self._on_latency)
        self._net.checked.connect(self._on_checked)

        self._sampler.sampled.connect(self._on_sample)
        self._sampler.failed.connect(self._on_sampler_error)

        self._refresh_btn.clicked.connect(self._manual_check)
        self._copy_btn.clicked.connect(self._copy_ip)

    # =============================================================== сеть
    def _on_network_state(self, state: str) -> None:
        self._pill.set_state(state)
        checking = state == "checking"
        self._refresh_btn.setEnabled(not checking)
        self._refresh_btn.setText("Проверка…" if checking else "Проверить IP")

        if checking:
            self._net_meta.setText("Запрашиваем публичный IP…")
            return

        if state in ("online", "offline"):
            previous = self._last_state
            if previous in ("online", "offline") and previous != state:
                if state == "online":
                    self._store.log("network", "Соединение восстановлено")
                else:
                    self._store.log("network", "Соединение потеряно")
            self._last_state = state

    def _on_ip(self, ip: str) -> None:
        changed = ip != self._current_ip
        self._current_ip = ip
        self._set_ip_text(ip)
        self._copy_btn.setEnabled(True)

        if changed:
            if self._had_ip:
                self._store.log(
                    "network", f"Публичный IP изменился: {ip}", {"ip": ip}
                )
            else:
                self._store.log(
                    "network", f"Публичный IP получен: {ip}", {"ip": ip}
                )
                self._had_ip = True

        self._update_net_meta()

    def _set_ip_text(self, ip: str) -> None:
        """Подобрать размер шрифта, чтобы длинный IPv6 не вылезал за карточку."""
        self._ip_label.setText(ip)
        size = 21 if len(ip) <= 15 else 17 if len(ip) <= 24 else 13
        self._ip_label.setFont(mono_font(size, bold=True))

    def _on_latency(self, latency_ms: int) -> None:
        self._latency_ms = latency_ms
        self._update_net_meta()

    def _on_checked(self, ok: bool) -> None:
        self._last_check = datetime.now().strftime("%H:%M:%S")
        if ok:
            self._update_net_meta()
        else:
            self._net_meta.setText(
                f"Последняя попытка {self._last_check} · нет соединения · "
                f"повтор через {NETWORK_REFRESH_MS // 1000} с"
            )

    def _update_net_meta(self) -> None:
        parts: list[str] = []
        if self._last_check:
            parts.append(f"Обновлено {self._last_check}")
        if self._latency_ms is not None:
            parts.append(f"Задержка {self._latency_ms} мс")
        parts.append(f"Автообновление {NETWORK_REFRESH_MS // 1000} с")
        self._net_meta.setText(" · ".join(parts))

    def _manual_check(self) -> None:
        if self._net.is_busy():
            return
        self._store.log("network", "Ручная проверка публичного IP")
        self._net.check()

    def _copy_ip(self) -> None:
        if not self._current_ip:
            return
        QGuiApplication.clipboard().setText(self._current_ip)
        self._store.log(
            "ui",
            "IP-адрес скопирован в буфер обмена",
            {"ip": self._current_ip},
        )
        self._copy_btn.setText("Скопировано")
        self._copy_reset.start()

    # ============================================================ система
    def _on_sample(self, data: dict) -> None:
        self._sampler_error_logged = False

        cores = data.get("cores", 0)
        self._cpu_card.update_metrics(
            data.get("cpu", 0.0),
            _cores_text(cores),
        )
        self._mem_card.update_metrics(
            data.get("mem_percent", 0.0),
            f"{_gb(data.get('mem_used_gb', 0.0))} ГБ из "
            f"{_gb(data.get('mem_total_gb', 0.0))} ГБ",
        )
        self._disk_card.update_metrics(
            data.get("disk_percent", 0.0),
            f"{data.get('disk_root', '')} · "
            f"{data.get('disk_used_gb', 0.0):.0f} из "
            f"{data.get('disk_total_gb', 0.0):.0f} ГБ",
        )

    def _on_sampler_error(self, message: str) -> None:
        # Не засоряем журнал одинаковыми ошибками каждую секунду.
        if self._sampler_error_logged:
            return
        self._sampler_error_logged = True
        self._store.log("system", f"Ошибка системного монитора: {message}")

    # ============================================================ сервис
    def _open_log_folder(self) -> None:
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(database_path().parent)))
        self._store.log("ui", "Открыта папка с локальным журналом")

    def _restore_geometry(self) -> None:
        geometry = self._settings.value("window/geometry")
        if geometry is not None:
            self.restoreGeometry(geometry)

    # ===================================================== адаптивная вёрстка
    def _apply_responsive_layout(self) -> None:
        """Перестроить карточки и панели под текущую ширину окна."""
        if not hasattr(self, "_splitter"):
            return

        width = self.width()
        narrow = width < 1080

        if narrow != self._narrow:
            self._narrow = narrow
            if narrow:
                # Узкое окно: история уезжает вниз, метрики — в один ряд.
                self._splitter.setOrientation(Qt.Orientation.Vertical)
                self._history.setMinimumWidth(0)
                self._history.setMinimumHeight(240)
                self._left_scroll.setMinimumWidth(0)
                self._left_scroll.setMinimumHeight(300)
                self._splitter.setSizes([380, 350])
            else:
                self._splitter.setOrientation(Qt.Orientation.Horizontal)
                self._history.setMinimumHeight(0)
                self._history.setMinimumWidth(380)
                self._left_scroll.setMinimumHeight(0)
                self._left_scroll.setMinimumWidth(440)
                self._splitter.setSizes([max(560, width - 500), 440])

        columns = 3 if width >= 1240 else 2 if width >= 820 else 1
        if self._narrow:
            # В вертикальной компоновке левая панель занимает всю ширину,
            # поэтому три карточки помещаются в один ряд уже с ~860 px.
            columns = 3 if width >= 860 else 2 if width >= 620 else 1
        self._relayout_metrics(columns)

    def _relayout_metrics(self, columns: int) -> None:
        """Разложить три карточки метрик в нужное число колонок."""
        if columns == self._metric_cols:
            return
        self._metric_cols = columns

        for card in self._metric_cards:
            self._metrics_grid.removeWidget(card)

        for index, card in enumerate(self._metric_cards):
            row, column = divmod(index, columns)
            span = 1
            # Последняя карточка, оставшаяся одна в ряду, занимает всю ширину.
            if index == len(self._metric_cards) - 1 and index % columns == 0:
                span = columns
            self._metrics_grid.addWidget(card, row, column, 1, span)

        for column in range(3):
            self._metrics_grid.setColumnStretch(column, 1 if column < columns else 0)

    def resizeEvent(self, event) -> None:  # noqa: N802 — метод Qt
        super().resizeEvent(event)
        self._apply_responsive_layout()

    def showEvent(self, event) -> None:  # noqa: N802 — метод Qt
        super().showEvent(event)
        if self._shown:
            return
        self._shown = True
        self._play_intro()

    def _play_intro(self) -> None:
        """Короткое каскадное появление карточек."""
        widgets = [self._network_card, *self._metric_cards, self._history]
        for index, widget in enumerate(widgets):
            fade_in(widget, delay_ms=index * 55, duration_ms=300, keep=self._animations)

    # =============================================================== выход
    def closeEvent(self, event) -> None:  # noqa: N802 — метод Qt
        self._store.log("system", "Приложение закрыто")
        self._settings.setValue("window/geometry", self.saveGeometry())

        self._net.stop()
        self._sampler.stop()
        self._store.close()
        super().closeEvent(event)


def _gb(value: float) -> str:
    """Гигабайты с запятой в качестве десятичного разделителя."""
    return f"{value:.1f}".replace(".", ",")


def _cores_text(count: int) -> str:
    """Правильное склонение «ядро» для русского интерфейса."""
    if count % 10 == 1 and count % 100 != 11:
        word = "логическое ядро"
    elif count % 10 in (2, 3, 4) and count % 100 not in (12, 13, 14):
        word = "логических ядра"
    else:
        word = "логических ядер"
    return f"{count} {word}"
