"""Панель истории действий: поиск, таблица и очистка журнала."""

from __future__ import annotations

from typing import Any

from PyQt6.QtCore import QAbstractTableModel, QModelIndex, QTimer, Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QAbstractItemView,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from core import theme
from core.config import HISTORY_LIMIT, SEARCH_DEBOUNCE_MS
from core.database import LogStore
from core.theme import mono_font
from ui.widgets import Card


class HistoryModel(QAbstractTableModel):
    """Лёгкая модель таблицы: хранит уже загруженные строки, не ходит в БД."""

    HEADERS = ("Время", "Категория", "Событие")

    KIND_LABELS = {
        "system": "Система",
        "network": "Сеть",
        "search": "Поиск",
        "ui": "Интерфейс",
    }
    KIND_COLORS = {
        "system": theme.MUTED,
        "network": theme.ACCENT,
        "search": theme.VIOLET,
        "ui": theme.GREEN,
    }

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._rows: list[dict[str, Any]] = []
        self._mono = mono_font(9)

    def set_rows(self, rows: list[dict[str, Any]]) -> None:
        self.beginResetModel()
        self._rows = rows
        self.endResetModel()

    # -------------------------------------------------------------- Qt-модель
    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self.HEADERS)

    def headerData(  # noqa: N802
        self,
        section: int,
        orientation: Qt.Orientation,
        role: int = Qt.ItemDataRole.DisplayRole,
    ):
        if (
            orientation == Qt.Orientation.Horizontal
            and role == Qt.ItemDataRole.DisplayRole
            and 0 <= section < len(self.HEADERS)
        ):
            return self.HEADERS[section]
        return None

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self._rows)):
            return None

        row = self._rows[index.row()]
        column = index.column()
        kind = row.get("kind", "")

        if role == Qt.ItemDataRole.DisplayRole:
            if column == 0:
                return self._format_ts(row.get("ts", ""))
            if column == 1:
                return self.KIND_LABELS.get(kind, kind)
            return row.get("message", "")

        if role == Qt.ItemDataRole.ForegroundRole:
            if column == 0:
                return QColor(theme.MUTED_DIM)
            if column == 1:
                return QColor(self.KIND_COLORS.get(kind, theme.MUTED))
            return QColor(theme.TEXT)

        if role == Qt.ItemDataRole.FontRole and column == 0:
            return self._mono

        if role == Qt.ItemDataRole.TextAlignmentRole:
            return Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter

        if role == Qt.ItemDataRole.ToolTipRole:
            parts = [
                row.get("ts", ""),
                self.KIND_LABELS.get(kind, kind),
                row.get("message", ""),
            ]
            meta = row.get("meta")
            if meta:
                parts.append(str(meta))
            return "\n".join(parts)

        return None

    @staticmethod
    def _format_ts(ts: str) -> str:
        """2026-11-22 14:03:11 → 22.11 14:03:11."""
        if len(ts) >= 19:
            return f"{ts[8:10]}.{ts[5:7]} {ts[11:19]}"
        return ts


class HistoryPanel(Card):
    """Карточка с журналом действий и поиском по нему."""

    def __init__(self, store: LogStore, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._store = store
        self._query = ""
        self._last_logged_query = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 12, 14)
        layout.setSpacing(10)

        # ---------------------------------------------------------- заголовок
        header = QHBoxLayout()
        header.setSpacing(10)
        title = QLabel("ИСТОРИЯ ДЕЙСТВИЙ")
        title.setObjectName("CardTitle")
        self._count_label = QLabel("Записей: 0")
        self._count_label.setObjectName("Hint")
        clear_button = QPushButton("Очистить")
        clear_button.setObjectName("Danger")
        clear_button.setCursor(Qt.CursorShape.PointingHandCursor)
        clear_button.clicked.connect(self._confirm_clear)
        header.addWidget(title)
        header.addWidget(self._count_label)
        header.addStretch(1)
        header.addWidget(clear_button)
        layout.addLayout(header)

        # -------------------------------------------------------------- поиск
        self._search_edit = QLineEdit()
        self._search_edit.setPlaceholderText("Поиск по истории…")
        self._search_edit.setClearButtonEnabled(True)
        self._search_edit.textChanged.connect(self._on_search_changed)
        layout.addWidget(self._search_edit)

        # ------------------------------------------------------------- таблица
        self._model = HistoryModel(self)
        self._table = QTableView()
        self._table.setModel(self._model)
        self._table.setFrameShape(QFrame.Shape.NoFrame)
        self._table.setShowGrid(False)
        self._table.setWordWrap(False)
        self._table.setAlternatingRowColors(False)
        self._table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self._table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        self._table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._table.setTextElideMode(Qt.TextElideMode.ElideRight)
        self._table.verticalHeader().setVisible(False)
        self._table.verticalHeader().setDefaultSectionSize(36)
        self._table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Fixed)

        table_header = self._table.horizontalHeader()
        table_header.setHighlightSections(False)
        table_header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        table_header.setSectionResizeMode(1, QHeaderView.ResizeMode.Fixed)
        table_header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self._table.setColumnWidth(0, 118)
        self._table.setColumnWidth(1, 96)

        # ------------------------------------------------------- пустое состояние
        empty_page = QWidget()
        empty_layout = QVBoxLayout(empty_page)
        empty_layout.setContentsMargins(16, 16, 16, 16)
        empty_layout.addStretch(1)
        self._empty_title = QLabel("Событий пока нет")
        self._empty_title.setObjectName("EmptyTitle")
        self._empty_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty_hint = QLabel(
            "Здесь появятся проверки IP, поисковые запросы\nи другие действия внутри приложения."
        )
        self._empty_hint.setObjectName("EmptyHint")
        self._empty_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty_hint.setWordWrap(True)
        empty_layout.addWidget(self._empty_title)
        empty_layout.addWidget(self._empty_hint)
        empty_layout.addStretch(1)

        self._stack = QStackedWidget()
        self._stack.addWidget(self._table)
        self._stack.addWidget(empty_page)
        layout.addWidget(self._stack, 1)

        footer = QLabel(f"SQLite · последние {HISTORY_LIMIT} записей")
        footer.setObjectName("Footer")
        layout.addWidget(footer)

        # --------------------------------------------------------- таймеры
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(SEARCH_DEBOUNCE_MS)
        self._search_timer.timeout.connect(self._apply_search)

        self._reload_timer = QTimer(self)
        self._reload_timer.setSingleShot(True)
        self._reload_timer.setInterval(120)
        self._reload_timer.timeout.connect(self.reload)

        self._store.eventsAdded.connect(self._schedule_reload)
        self._store.cleared.connect(self._schedule_reload)

        self.reload()

    # ------------------------------------------------------------------ данные
    def reload(self) -> None:
        """Перечитать журнал с учётом текущего фильтра."""
        rows = self._store.fetch(limit=HISTORY_LIMIT, query=self._query)
        self._model.set_rows(rows)

        if rows:
            self._stack.setCurrentWidget(self._table)
            prefix = "Найдено" if self._query else "Записей"
            self._count_label.setText(f"{prefix}: {len(rows)}")
        else:
            self._stack.setCurrentIndex(1)
            self._count_label.setText("Найдено: 0" if self._query else "Записей: 0")
            if self._query:
                self._empty_title.setText("Ничего не найдено")
                self._empty_hint.setText("Попробуйте изменить поисковый запрос.")
            else:
                self._empty_title.setText("Событий пока нет")
                self._empty_hint.setText(
                    "Здесь появятся проверки IP, поисковые запросы\n"
                    "и другие действия внутри приложения."
                )

    def _schedule_reload(self, *_args) -> None:
        self._reload_timer.start()

    # ------------------------------------------------------------------ поиск
    def _on_search_changed(self, _text: str) -> None:
        self._search_timer.start()

    def _apply_search(self) -> None:
        text = self._search_edit.text().strip()
        self._query = text
        self.reload()

        # Пишем в лог только осмысленные паузы в наборе, без спама на каждую букву.
        if text and text != self._last_logged_query:
            self._last_logged_query = text
            self._store.log("search", f"Поиск: «{text}»", {"query": text})
        elif not text:
            self._last_logged_query = ""

    # ---------------------------------------------------------------- очистка
    def _confirm_clear(self) -> None:
        box = QMessageBox(self)
        box.setWindowTitle("Очистить историю")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("Удалить все записи локального журнала?")
        box.setInformativeText("Это действие нельзя отменить.")
        delete_button = box.addButton("Удалить", QMessageBox.ButtonRole.DestructiveRole)
        delete_button.setObjectName("Danger")
        cancel_button = box.addButton("Отмена", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(cancel_button)
        box.setEscapeButton(cancel_button)
        box.exec()

        if box.clickedButton() is not delete_button:
            return

        self._store.clear()

        # Сбрасываем фильтр, чтобы очистка выглядела предсказуемо.
        self._search_edit.blockSignals(True)
        self._search_edit.clear()
        self._search_edit.blockSignals(False)
        self._query = ""
        self._last_logged_query = ""
        self.reload()
        self._store.log("system", "История действий очищена")
