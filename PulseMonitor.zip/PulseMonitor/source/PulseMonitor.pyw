"""Pulse Monitor без консольного окна.

В Windows двойной клик по файлу .pyw запускает его через pythonw.exe,
поэтому консоль не появляется. Из терминала:

    pythonw PulseMonitor.pyw

Этот файл — лишь тонкая обёртка над main.py, чтобы сохранить возможность
обычного запуска через `python main.py` для отладки.
"""

from __future__ import annotations

from main import main

if __name__ == "__main__":
    raise SystemExit(main())
