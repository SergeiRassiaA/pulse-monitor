﻿# ---------------------------------------------------------------------------
#  Pulse Monitor — необязательная проверка Python-зависимостей.
#
#  Зачем: установленный PulseMonitor.exe собран PyInstaller с --onefile и уже
#  содержит Python, PyQt6 и psutil. Этот скрипт нужен только тем, кто хочет
#  запускать приложение из исходников (папка source) через python/pythonw.
#
#  Что делает:
#    1. ищет Python (py.exe, python.exe, стандартные папки установки);
#    2. проверяет импорт PyQt6 и psutil;
#    3. если чего-то нет — спрашивает разрешение и ставит через pip;
#    4. если Python не найден — предлагает поставить его через winget.
#
#  Запуск вручную: правый клик -> «Выполнить с помощью PowerShell» или
#  powershell -ExecutionPolicy Bypass -File check_deps.ps1
#
#  Диагностика без окон и установки:
#  powershell -ExecutionPolicy Bypass -File check_deps.ps1 -CheckOnly
# ---------------------------------------------------------------------------

param(
    [switch]$CheckOnly
)

Add-Type -AssemblyName System.Windows.Forms | Out-Null

$Title = 'Pulse Monitor'
$DownloadPage = 'https://www.python.org/downloads/windows/'

function Show-Info {
    param([string]$Text)
    [System.Windows.Forms.MessageBox]::Show(
        $Text, $Title,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Ask-YesNo {
    param([string]$Text)
    $answer = [System.Windows.Forms.MessageBox]::Show(
        $Text, $Title,
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question,
        [System.Windows.Forms.MessageBoxDefaultButton]::Button2
    )
    return $answer -eq [System.Windows.Forms.DialogResult]::Yes
}

# Найти рабочий python.exe. Возвращает полный путь или $null.
function Find-Python {
    $candidates = New-Object System.Collections.Generic.List[string]

    foreach ($name in @('py', 'python', 'python3')) {
        $command = Get-Command $name -ErrorAction SilentlyContinue
        if ($command -and $command.Source) {
            # Псевдонимы из WindowsApps открывают Microsoft Store — пропускаем.
            if ($command.Source -notlike '*\WindowsApps\*') {
                $candidates.Add($command.Source)
            }
        }
    }

    foreach ($pattern in @(
        "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe",
        "$env:ProgramFiles\Python3*\python.exe",
        "${env:ProgramFiles(x86)}\Python3*\python.exe"
    )) {
        Get-ChildItem $pattern -ErrorAction SilentlyContinue |
            Sort-Object FullName -Descending |
            ForEach-Object { $candidates.Add($_.FullName) }
    }

    foreach ($exe in ($candidates | Select-Object -Unique)) {
        # py.exe — это лаунчер, ему нужен аргумент -3.
        if ([System.IO.Path]::GetFileName($exe) -ieq 'py.exe') {
            $pyArgs = @('-3', '-c', 'import sys; print(sys.executable)')
        } else {
            $pyArgs = @('-c', 'import sys; print(sys.executable)')
        }

        $output = & $exe @pyArgs 2>$null
        if ($LASTEXITCODE -eq 0 -and $output) {
            $path = ($output | Select-Object -First 1).ToString().Trim()
            if ($path -and (Test-Path $path)) {
                return $path
            }
        }
    }

    return $null
}

function Test-Libraries {
    param([string]$Python)
    & $Python -c 'import PyQt6, psutil' 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Install-Libraries {
    param([string]$Python)
    $pipArgs = @(
        '-m', 'pip', 'install',
        '--user',
        '--disable-pip-version-check',
        'PyQt6', 'psutil'
    )
    # Окно pip оставляем видимым: пользователь видит прогресс и ошибки.
    $process = Start-Process -FilePath $Python -ArgumentList $pipArgs -Wait -PassThru
    return ($process.ExitCode -eq 0)
}

function Install-Python {
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) {
        return $false
    }

    $wingetArgs = @(
        'install', '--id', 'Python.Python.3.12', '-e',
        '--silent',
        '--accept-package-agreements',
        '--accept-source-agreements',
        '--disable-interactivity'
    )
    $process = Start-Process -FilePath $winget.Source -ArgumentList $wingetArgs -Wait -PassThru
    return ($process.ExitCode -eq 0)
}

# --- Основной сценарий -----------------------------------------------------

if ($CheckOnly) {
    $found = Find-Python
    if (-not $found) {
        Write-Output 'PYTHON: not found'
        exit 1
    }
    Write-Output "PYTHON: $found"
    if (Test-Libraries $found) {
        Write-Output 'LIBS: OK'
        exit 0
    }
    Write-Output 'LIBS: missing'
    exit 2
}

$python = Find-Python

if (-not $python) {
    $question = @"
Python не найден.

PulseMonitor.exe уже содержит все библиотеки и работает без Python.
Python нужен только для запуска из папки source (python main.py).

Установить Python 3.12 через winget и затем PyQt6/psutil?
"@
    if (-not (Ask-YesNo $question)) {
        exit 0
    }

    if (-not (Install-Python)) {
        Show-Info @"
Не удалось установить Python автоматически (winget недоступен или отменил установку).

PulseMonitor.exe продолжит работать без Python.
Если нужен режим исходников, установите Python вручную:
$DownloadPage
"@
        Start-Process $DownloadPage | Out-Null
        exit 0
    }

    # PATH текущего процесса не обновился — Find-Python ищет и по папкам.
    $python = Find-Python
    if (-not $python) {
        Show-Info @"
Python установлен, но найти python.exe не удалось.
Перезапустите этот скрипт или установите Python вручную:
$DownloadPage
"@
        exit 0
    }
}

if (Test-Libraries $python) {
    # Всё на месте — молча выходим, чтобы не мешать пользователю.
    exit 0
}

$question = @"
Python найден:
$python

Библиотеки PyQt6 и psutil не установлены.

Установить их сейчас через pip?
Это нужно только для запуска из папки source.
PulseMonitor.exe работает и без них.
"@
if (-not (Ask-YesNo $question)) {
    exit 0
}

if (Install-Libraries $python) {
    if (Test-Libraries $python) {
        Show-Info "Готово: PyQt6 и psutil установлены.`n`nТеперь можно запускать source\main.py или source\PulseMonitor.pyw."
    } else {
        Show-Info "pip завершился успешно, но импорт PyQt6/psutil всё ещё не работает.`n`nПроверьте версию Python (нужен 64-битный Python 3.10+) и повторите установку."
    }
} else {
    Show-Info "Не удалось установить PyQt6 и psutil.`n`nПроверьте подключение к интернету и выполните вручную:`n$python -m pip install --user PyQt6 psutil"
}
